//Datepickerの設定
$(function() {
	$(".datepicker").datepicker({
		dateFormat: "yy-mm-dd"
	});
});
