<?php

/* common/err_msg.html */
class __TwigTemplate_782333a797b36ee626c44564560744c8630443971bdf8e25e3f05c94c243069a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((($context["err"] ?? null) == "1")) {
            // line 2
            echo "\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["err_msg"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 3
                echo "\t\t<p class=\"err_msg\">";
                echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                echo "</p>
\t\t<div class=\"spacer\"></div>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
    }

    public function getTemplateName()
    {
        return "common/err_msg.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if err == \"1\" %}
\t{% for item in err_msg %}
\t\t<p class=\"err_msg\">{{ item }}</p>
\t\t<div class=\"spacer\"></div>
\t{% endfor %}
{% endif %}", "common/err_msg.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\common\\err_msg.html");
    }
}
