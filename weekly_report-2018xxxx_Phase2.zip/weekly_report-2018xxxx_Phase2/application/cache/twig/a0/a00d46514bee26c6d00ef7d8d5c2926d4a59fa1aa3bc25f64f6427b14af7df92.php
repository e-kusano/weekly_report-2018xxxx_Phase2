<?php

/* common/body_header.html */
class __TwigTemplate_501a2d61337d654538e02df0018189e66dd572077cd9e8c55e2f0650dd105282 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<body>
<header id=\"header\">
\t<div id=\"titleBox\">
\t<div id=\"title-contents\" class=\"cf\">
\t<!-- \t<h1>
\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t";
        // line 7
        echo twig_include($this->env, $context, "common/logout.html");
        echo "
\t</h1> -->
\t    <h1>
\t\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t</h1>
\t\t<div id=\"logout-contents\" class=\"cf\">";
        // line 12
        echo twig_include($this->env, $context, "common/logout.html");
        echo "</div>\t\t
\t</div>
\t</div>
\t<div id=\"header-contents\" class=\"cf\">
\t\t<div id=\"logo\">
\t\t\t<a href=\"";
        // line 17
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "WeeklyReportList\">
\t\t\t\t<img alt=\"株式会社ミライタス\" src=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/_images/logo.gif\">
\t\t\t</a>
\t\t</div>
\t</div>
</header>";
    }

    public function getTemplateName()
    {
        return "common/body_header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 18,  43 => 17,  35 => 12,  27 => 7,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<body>
<header id=\"header\">
\t<div id=\"titleBox\">
\t<div id=\"title-contents\" class=\"cf\">
\t<!-- \t<h1>
\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t{{ include('common/logout.html') }}
\t</h1> -->
\t    <h1>
\t\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t</h1>
\t\t<div id=\"logout-contents\" class=\"cf\">{{ include('common/logout.html') }}</div>\t\t
\t</div>
\t</div>
\t<div id=\"header-contents\" class=\"cf\">
\t\t<div id=\"logo\">
\t\t\t<a href=\"{{ base_url }}WeeklyReportList\">
\t\t\t\t<img alt=\"株式会社ミライタス\" src=\"{{ base_url }}view/_images/logo.gif\">
\t\t\t</a>
\t\t</div>
\t</div>
</header>", "common/body_header.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\common\\body_header.html");
    }
}
