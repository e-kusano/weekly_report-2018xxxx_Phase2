<?php

/* common/header.html */
class __TwigTemplate_8d0a7d3f608d75732a7a0c4208615531ccdbc66b84fcbc30ddeb0a0247cfe29f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html lang=\"ja\">
<head>
\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
\t<title>週報システム｜株式会社ミライタス</title>
\t<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no\">
\t<link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/html5reset-1.6.1.css\" />
\t<link href=\"http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
\t<link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/PaginateMyTable.css\" />
\t<link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style.css\" />
\t<link type=\"text/css\" href=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/ui-lightness/jquery-ui.css\" rel=\"stylesheet\" />
\t<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>
\t<link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-sp.css\" media=\"only screen and (min-width: 0px) and (max-width: 480px)\" />
\t<link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-tb.css\" media=\"only screen and (min-width: 481px) and (max-width: 768px)\"/>
\t<link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-ipad.css\" media=\"only screen and (min-width: 769px) and (max-width: 1024px)\"/>
\t<link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-pc.css\" media=\"only screen and (min-width: 1025px) \"/>
\t<script src=\"http://code.jquery.com/ui/1.9.2/jquery-ui.js\"></script>
\t<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js\"></script>
\t<script type=\"text/javascript\" src=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1/i18n/jquery.ui.datepicker-ja.min.js\"></script>
\t<script src=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/js/app.js\"></script>
\t<script src=\"";
        // line 20
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/js/function.js\"></script>
\t<script src=\"";
        // line 21
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/js/PaginateMyTable.js\"></script>
</head>";
    }

    public function getTemplateName()
    {
        return "common/header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 21,  64 => 20,  60 => 19,  53 => 15,  49 => 14,  45 => 13,  41 => 12,  35 => 9,  31 => 8,  26 => 6,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html lang=\"ja\">
<head>
\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
\t<title>週報システム｜株式会社ミライタス</title>
\t<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no\">
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/html5reset-1.6.1.css\" />
\t<link href=\"http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/PaginateMyTable.css\" />
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style.css\" />
\t<link type=\"text/css\" href=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/ui-lightness/jquery-ui.css\" rel=\"stylesheet\" />
\t<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js\"></script>
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-sp.css\" media=\"only screen and (min-width: 0px) and (max-width: 480px)\" />
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-tb.css\" media=\"only screen and (min-width: 481px) and (max-width: 768px)\"/>
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-ipad.css\" media=\"only screen and (min-width: 769px) and (max-width: 1024px)\"/>
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-pc.css\" media=\"only screen and (min-width: 1025px) \"/>
\t<script src=\"http://code.jquery.com/ui/1.9.2/jquery-ui.js\"></script>
\t<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js\"></script>
\t<script type=\"text/javascript\" src=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1/i18n/jquery.ui.datepicker-ja.min.js\"></script>
\t<script src=\"{{ base_url }}view/js/app.js\"></script>
\t<script src=\"{{ base_url }}view/js/function.js\"></script>
\t<script src=\"{{ base_url }}view/js/PaginateMyTable.js\"></script>
</head>", "common/header.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\common\\header.html");
    }
}
