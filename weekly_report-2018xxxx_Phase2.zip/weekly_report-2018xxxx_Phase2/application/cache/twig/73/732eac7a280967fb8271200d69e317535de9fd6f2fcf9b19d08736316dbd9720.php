<?php

/* common/logout.html */
class __TwigTemplate_5f77d3839e38d305ed77cee23bfd982bccc8a54bad6eb66b25ba3d53625cd75c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if (($this->getAttribute($this->getAttribute(($context["session"] ?? null), "userdata", array()), "is_login", array()) == "1")) {
            // line 2
            echo "\t<p id=\"welcome\"><span class=\"tb-none\">ようこそ </span>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["session"] ?? null), "userdata", array()), "user_name", array()), "html", null, true);
            echo " さん <i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i></p>
\t<p id=\"logout\"><a href=\"";
            // line 3
            echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
            echo "Logout\">ログアウト <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i></a></p>
";
        }
    }

    public function getTemplateName()
    {
        return "common/logout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  21 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if session.userdata.is_login == \"1\" %}
\t<p id=\"welcome\"><span class=\"tb-none\">ようこそ </span>{{ session.userdata.user_name}} さん <i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i></p>
\t<p id=\"logout\"><a href=\"{{ base_url }}Logout\">ログアウト <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i></a></p>
{% endif %}", "common/logout.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\common\\logout.html");
    }
}
