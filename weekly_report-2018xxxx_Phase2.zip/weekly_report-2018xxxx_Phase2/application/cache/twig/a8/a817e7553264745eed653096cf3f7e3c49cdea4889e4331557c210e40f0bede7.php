<?php

/* login/login.html */
class __TwigTemplate_a921de67e11e439b1fb54223f26ca4f8dac02cbfc3a13f7a68f9bf5789c5de6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html lang=\"ja\">
<head>
\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
\t<title>週報システム｜株式会社ミライタス</title>
\t<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no\">
\t<link rel=\"icon\" href=\"\">
\t<link rel=\"apple-touch-icon\" href=\"\" />
\t<link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/html5reset-1.6.1.css\" />
\t<link href=\"http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
\t<link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style.css\" />
\t<link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-sp.css\" media=\"only screen and (min-width: 0px) and (max-width: 480px)\" />
\t<link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-tb.css\" media=\"only screen and (min-width: 481px) and (max-width: 768px)\"/>
\t<link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-ipad.css\" media=\"only screen and (min-width: 769px) and (max-width: 1024px)\"/>
\t<link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/css/style-pc.css\" media=\"only screen and (min-width: 1025px) \"/>
\t
\t<script src=\"";
        // line 16
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/js/app.js\"></script>
</head>

<body id=\"front\">
\t<header>
\t\t<div id=\"titleBox\">
\t\t<div id=\"title-contents\" class=\"cf\">
\t\t\t<h1>
\t\t\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t\t\t";
        // line 25
        echo twig_include($this->env, $context, "common/logout.html");
        echo "
\t\t\t</h1>
\t\t</div>
\t\t</div>
\t</header>
\t<div id=\"log-logo\">
\t\t<img alt=\"株式会社ミライタス\" src=\"";
        // line 31
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "view/_images/login_logo.gif\">
\t</div>
\t<div id=\"loginform\">
\t\t<form name=\"loginform\" class=\"login\" action=\"";
        // line 34
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "Login/validate\" method=\"post\">
\t\t\t";
        // line 35
        echo twig_include($this->env, $context, "common/err_msg.html");
        echo "
\t\t\t<dl>
\t\t\t\t<dt>ユーザーID</dt>
\t\t\t\t<dd><input type=\"text\" name=\"user_id\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, ($context["user_id"] ?? null), "html", null, true);
        echo "\" autocomplete=\"user_id\" /></dd>
\t\t\t\t<dt>パスワード</dt>
\t\t\t\t<dd><input type=\"password\" name=\"password\"/></dd>
\t\t\t</dl>
\t\t\t<input type=\"submit\" id=\"btn_login\" value=\"ログイン\">
\t\t</form>
\t</div>
</body>

</html>";
    }

    public function getTemplateName()
    {
        return "login/login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 38,  85 => 35,  81 => 34,  75 => 31,  66 => 25,  54 => 16,  49 => 14,  45 => 13,  41 => 12,  37 => 11,  33 => 10,  28 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html lang=\"ja\">
<head>
\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
\t<title>週報システム｜株式会社ミライタス</title>
\t<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no\">
\t<link rel=\"icon\" href=\"\">
\t<link rel=\"apple-touch-icon\" href=\"\" />
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/html5reset-1.6.1.css\" />
\t<link href=\"http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style.css\" />
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-sp.css\" media=\"only screen and (min-width: 0px) and (max-width: 480px)\" />
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-tb.css\" media=\"only screen and (min-width: 481px) and (max-width: 768px)\"/>
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-ipad.css\" media=\"only screen and (min-width: 769px) and (max-width: 1024px)\"/>
\t<link rel=\"stylesheet\" href=\"{{ base_url }}view/css/style-pc.css\" media=\"only screen and (min-width: 1025px) \"/>
\t
\t<script src=\"{{ base_url }}view/js/app.js\"></script>
</head>

<body id=\"front\">
\t<header>
\t\t<div id=\"titleBox\">
\t\t<div id=\"title-contents\" class=\"cf\">
\t\t\t<h1>
\t\t\t\t<span class=\"site-title\">週報システム</span> | 株式会社ミライタス
\t\t\t\t{{ include('common/logout.html') }}
\t\t\t</h1>
\t\t</div>
\t\t</div>
\t</header>
\t<div id=\"log-logo\">
\t\t<img alt=\"株式会社ミライタス\" src=\"{{ base_url }}view/_images/login_logo.gif\">
\t</div>
\t<div id=\"loginform\">
\t\t<form name=\"loginform\" class=\"login\" action=\"{{ base_url }}Login/validate\" method=\"post\">
\t\t\t{{ include('common/err_msg.html')}}
\t\t\t<dl>
\t\t\t\t<dt>ユーザーID</dt>
\t\t\t\t<dd><input type=\"text\" name=\"user_id\" value=\"{{user_id}}\" autocomplete=\"user_id\" /></dd>
\t\t\t\t<dt>パスワード</dt>
\t\t\t\t<dd><input type=\"password\" name=\"password\"/></dd>
\t\t\t</dl>
\t\t\t<input type=\"submit\" id=\"btn_login\" value=\"ログイン\">
\t\t</form>
\t</div>
</body>

</html>", "login/login.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\login\\login.html");
    }
}
