<?php

/* report/weekly_report_detail.html */
class __TwigTemplate_a0034ad61dd918c654ec65bfb1f4abc347d7f60fec3f9ab1e3ca07a86fe4dada extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo twig_include($this->env, $context, "common/header.html");
        echo "
";
        // line 2
        echo twig_include($this->env, $context, "common/body_header.html");
        echo "

<div id=\"main-content\">
\t<div class=\"event-list\">
\t\t<div class=\"event-title cf\">
\t\t\t<h3><span class=\"brs\">";
        // line 7
        echo twig_escape_filter($this->env, ($context["weekly_report_name"] ?? null), "html", null, true);
        echo " </span></h3>
\t\t</div>
\t\t<div class=\"event-wrapper\">
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>参画プロジェクト名</h4>
\t\t\t\t<p>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report_detail_info"] ?? null), "project_name", array()), "html", null, true);
        echo "</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>作業内容</h4>
\t\t\t\t<p>";
        // line 16
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["report_detail_info"] ?? null), "work_content", array()), "html", null, true));
        echo "</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>作業に対する疑問/不明点/反省等</h4>
\t\t\t\t<p>";
        // line 20
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["report_detail_info"] ?? null), "reflect", array()), "html", null, true));
        echo "</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>その他</h4>
\t\t\t\t<p>";
        // line 24
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["report_detail_info"] ?? null), "other", array()), "html", null, true));
        echo "</p>
\t\t\t</div>
\t\t\t";
        // line 26
        if (($this->getAttribute($this->getAttribute(($context["session"] ?? null), "userdata", array()), "user_name", array()) == "管理者")) {
            // line 27
            echo "\t\t\t\t<p align=\"center\">
\t\t\t\t\t<input type=\"button\"  class=\"btn-excel\" value=\"Excelに出力する\" onclick=\"sub_redirect('";
            // line 28
            echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
            echo "','WeeklyReportList', 'excel', '";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["report_detail_info"] ?? null), "id", array()), "html", null, true);
            echo "');\">
\t\t\t\t</p>
\t\t\t";
        }
        // line 31
        echo "\t\t</div>
\t</div>
\t<div class=\"spacer\"></div>
\t<div id=\"btn-entry\">
\t\t<p align=\"center\">
\t\t\t<input type=\"button\" class=\"btn_return\" value=\"トップページに戻る\" onclick=\"sub_redirect('";
        // line 36
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "','WeeklyReportList');\">
\t\t</p>
\t</div>
</div>
";
        // line 40
        echo twig_include($this->env, $context, "common/footer.html");
    }

    public function getTemplateName()
    {
        return "report/weekly_report_detail.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 40,  85 => 36,  78 => 31,  70 => 28,  67 => 27,  65 => 26,  60 => 24,  53 => 20,  46 => 16,  39 => 12,  31 => 7,  23 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('common/header.html')}}
{{ include('common/body_header.html')}}

<div id=\"main-content\">
\t<div class=\"event-list\">
\t\t<div class=\"event-title cf\">
\t\t\t<h3><span class=\"brs\">{{ weekly_report_name }} </span></h3>
\t\t</div>
\t\t<div class=\"event-wrapper\">
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>参画プロジェクト名</h4>
\t\t\t\t<p>{{ report_detail_info.project_name }}</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>作業内容</h4>
\t\t\t\t<p>{{ report_detail_info.work_content|nl2br }}</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>作業に対する疑問/不明点/反省等</h4>
\t\t\t\t<p>{{ report_detail_info.reflect|nl2br }}</p>
\t\t\t</div>
\t\t\t<div class=\"event-content\">
\t\t\t\t<h4><i class=\"fa\" aria-hidden=\"true\"></i>その他</h4>
\t\t\t\t<p>{{ report_detail_info.other|nl2br }}</p>
\t\t\t</div>
\t\t\t{% if session.userdata.user_name == '管理者' %}
\t\t\t\t<p align=\"center\">
\t\t\t\t\t<input type=\"button\"  class=\"btn-excel\" value=\"Excelに出力する\" onclick=\"sub_redirect('{{ base_url }}','WeeklyReportList', 'excel', '{{ report_detail_info.id }}');\">
\t\t\t\t</p>
\t\t\t{% endif %}
\t\t</div>
\t</div>
\t<div class=\"spacer\"></div>
\t<div id=\"btn-entry\">
\t\t<p align=\"center\">
\t\t\t<input type=\"button\" class=\"btn_return\" value=\"トップページに戻る\" onclick=\"sub_redirect('{{ base_url }}','WeeklyReportList');\">
\t\t</p>
\t</div>
</div>
{{ include('common/footer.html')}}", "report/weekly_report_detail.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\report\\weekly_report_detail.html");
    }
}
