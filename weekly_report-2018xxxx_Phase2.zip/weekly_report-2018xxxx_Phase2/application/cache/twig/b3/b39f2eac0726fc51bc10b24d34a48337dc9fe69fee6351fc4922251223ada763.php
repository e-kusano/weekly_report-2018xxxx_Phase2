<?php

/* report/weekly_report_list.html */
class __TwigTemplate_bfb322f3c3535f52ef3de28574b893e46952d6362c2cb6ad5d1193a066793af3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo twig_include($this->env, $context, "common/header.html");
        echo "
";
        // line 2
        echo twig_include($this->env, $context, "common/body_header.html");
        echo "

<script type=\"text/javascript\">
\$(document).ready(function() {
  \$(\".mytable\").paginate({
\t  rows: 10
  });
});
</script>

<div id=\"main-content\">
<div id=\"main-wrapper\" class=\"cf\">
\t<div id=\"left-wrapper\">
\t<h2>
\t\t";
        // line 16
        echo twig_escape_filter($this->env, ($context["wrapper_title"] ?? null), "html", null, true);
        echo "
\t</h2>
\t";
        // line 18
        if (($this->getAttribute($this->getAttribute(($context["session"] ?? null), "userdata", array()), "user_name", array()) != "管理者")) {
            // line 19
            echo "\t\t<input type=\"button\" id=\"regist\" class=\"btn_regist\" value=\"週報の提出\" onclick=\"sub_redirect('";
            echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
            echo "', 'WeeklyReportRegist', 'regist_input')\">
\t";
        }
        // line 21
        echo "<!-- \t<div class=\"spacer\"></div> -->
\t<div id=\"list-wrapper\">
\t<table border=\"0\" class=\"list mytable\">
\t\t";
        // line 24
        if ((twig_length_filter($this->env, ($context["list"] ?? null)) == 0)) {
            // line 25
            echo "\t\t\t<tr>
\t\t\t\t<td align=\"center\">データはありません。</td>
\t\t\t</tr>
\t\t";
        } else {
            // line 29
            echo "\t\t\t<thead>
\t\t\t\t<tr>
\t\t\t\t\t<td align=\"center\">編集</td>
\t\t\t\t\t<td>日付</td>
\t\t\t\t\t<td>作成者</td>
\t\t\t\t\t<td>詳細</td>
\t\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
\t\t\t\t";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["list"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 39
                echo "\t\t\t\t<tr>
\t\t\t\t\t<td align=\"center\"><a href=\"";
                // line 40
                echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
                echo "WeeklyReportRegist/modify_input/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a></td>
\t\t\t\t\t<td><i class=\"fa fa-calendar sp-none\" aria-hidden=\"true\"></i>";
                // line 41
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "date", array()), "html", null, true);
                echo "</td>
\t\t\t\t\t<td><i class=\"fa fa-user-circle-o sp-none\" aria-hidden=\"true\"></i>";
                // line 42
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
                echo "</td>
\t\t\t\t\t<td align=\"center\">
\t\t\t\t\t\t<input type=\"button\" class=\"btn_detail\" value=\"詳細\" onclick=\"sub_redirect('";
                // line 44
                echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
                echo "', 'WeeklyReportList', 'detail', '";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "')\">
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "\t\t\t</tbody>
\t\t";
        }
        // line 50
        echo "\t</table>
\t</div>
\t</div>
\t<div id=\"right-wrapper\">
\t\t<form action=\"";
        // line 54
        echo twig_escape_filter($this->env, ($context["base_url"] ?? null), "html", null, true);
        echo "WeeklyReportList/search\" method=\"post\">
\t\t\t<div class=\"search-list datepick-wrapper\">
\t\t\t\t<h3>日付検索</h3>
\t\t\t\t<!-- <div class=\"spacer\"></div> -->
\t\t\t\t<p class=\"start-date\">開始</p><input class=\"datepicker start-date-p\" type=\"text\" name=\"search_date_from\" value=\"";
        // line 58
        echo twig_escape_filter($this->env, ($context["search_date_from"] ?? null), "html", null, true);
        echo "\">
\t\t\t\t<div class=\"spacer\"></div>
\t\t\t\t<input class=\"datepicker\" type=\"text\" name=\"search_date_to\" value=\"";
        // line 60
        echo twig_escape_filter($this->env, ($context["search_date_to"] ?? null), "html", null, true);
        echo "\"><p class=\"end-date\">終了</p>
\t\t\t</div>
\t\t\t<div class=\"spacer\"></div>
\t\t\t";
        // line 63
        echo twig_include($this->env, $context, "report/list/search_col_val.html");
        echo "
\t\t\t<div class=\"spacer\"></div>
\t\t\t";
        // line 65
        if (($this->getAttribute($this->getAttribute(($context["session"] ?? null), "userdata", array()), "user_name", array()) == "管理者")) {
            // line 66
            echo "\t\t\t\t<div class=\"search-list\">
\t\t\t\t<h3>名前</h3>
\t\t\t\t";
            // line 68
            echo ($context["name_list"] ?? null);
            echo "
\t\t\t\t</div>
\t\t\t\t<div class=\"spacer\"></div>
\t\t\t";
        }
        // line 72
        echo "\t\t\t<div style=\"text-align:center;\">
\t\t\t\t<input type=\"submit\" class=\"btn_search\" align=\"center\" value=\"検索\">
\t\t\t</div>
\t\t</form>
\t</div>
</div>
</div>
";
        // line 79
        echo twig_include($this->env, $context, "common/footer.html");
    }

    public function getTemplateName()
    {
        return "report/weekly_report_list.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 79,  157 => 72,  150 => 68,  146 => 66,  144 => 65,  139 => 63,  133 => 60,  128 => 58,  121 => 54,  115 => 50,  111 => 48,  99 => 44,  94 => 42,  90 => 41,  84 => 40,  81 => 39,  77 => 38,  66 => 29,  60 => 25,  58 => 24,  53 => 21,  47 => 19,  45 => 18,  40 => 16,  23 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('common/header.html')}}
{{ include('common/body_header.html')}}

<script type=\"text/javascript\">
\$(document).ready(function() {
  \$(\".mytable\").paginate({
\t  rows: 10
  });
});
</script>

<div id=\"main-content\">
<div id=\"main-wrapper\" class=\"cf\">
\t<div id=\"left-wrapper\">
\t<h2>
\t\t{{ wrapper_title }}
\t</h2>
\t{% if session.userdata.user_name != '管理者' %}
\t\t<input type=\"button\" id=\"regist\" class=\"btn_regist\" value=\"週報の提出\" onclick=\"sub_redirect('{{ base_url }}', 'WeeklyReportRegist', 'regist_input')\">
\t{% endif %}
<!-- \t<div class=\"spacer\"></div> -->
\t<div id=\"list-wrapper\">
\t<table border=\"0\" class=\"list mytable\">
\t\t{% if list|length == 0%}
\t\t\t<tr>
\t\t\t\t<td align=\"center\">データはありません。</td>
\t\t\t</tr>
\t\t{% else %}
\t\t\t<thead>
\t\t\t\t<tr>
\t\t\t\t\t<td align=\"center\">編集</td>
\t\t\t\t\t<td>日付</td>
\t\t\t\t\t<td>作成者</td>
\t\t\t\t\t<td>詳細</td>
\t\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
\t\t\t\t{% for item in list%}
\t\t\t\t<tr>
\t\t\t\t\t<td align=\"center\"><a href=\"{{ base_url }}WeeklyReportRegist/modify_input/{{ item.id }}\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a></td>
\t\t\t\t\t<td><i class=\"fa fa-calendar sp-none\" aria-hidden=\"true\"></i>{{ item.date }}</td>
\t\t\t\t\t<td><i class=\"fa fa-user-circle-o sp-none\" aria-hidden=\"true\"></i>{{ item.name}}</td>
\t\t\t\t\t<td align=\"center\">
\t\t\t\t\t\t<input type=\"button\" class=\"btn_detail\" value=\"詳細\" onclick=\"sub_redirect('{{ base_url }}', 'WeeklyReportList', 'detail', '{{ item.id }}')\">
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t\t{% endfor %}
\t\t\t</tbody>
\t\t{% endif %}
\t</table>
\t</div>
\t</div>
\t<div id=\"right-wrapper\">
\t\t<form action=\"{{ base_url }}WeeklyReportList/search\" method=\"post\">
\t\t\t<div class=\"search-list datepick-wrapper\">
\t\t\t\t<h3>日付検索</h3>
\t\t\t\t<!-- <div class=\"spacer\"></div> -->
\t\t\t\t<p class=\"start-date\">開始</p><input class=\"datepicker start-date-p\" type=\"text\" name=\"search_date_from\" value=\"{{ search_date_from }}\">
\t\t\t\t<div class=\"spacer\"></div>
\t\t\t\t<input class=\"datepicker\" type=\"text\" name=\"search_date_to\" value=\"{{ search_date_to }}\"><p class=\"end-date\">終了</p>
\t\t\t</div>
\t\t\t<div class=\"spacer\"></div>
\t\t\t{{ include('report/list/search_col_val.html')}}
\t\t\t<div class=\"spacer\"></div>
\t\t\t{% if session.userdata.user_name == '管理者' %}
\t\t\t\t<div class=\"search-list\">
\t\t\t\t<h3>名前</h3>
\t\t\t\t{{ name_list|raw}}
\t\t\t\t</div>
\t\t\t\t<div class=\"spacer\"></div>
\t\t\t{% endif %}
\t\t\t<div style=\"text-align:center;\">
\t\t\t\t<input type=\"submit\" class=\"btn_search\" align=\"center\" value=\"検索\">
\t\t\t</div>
\t\t</form>
\t</div>
</div>
</div>
{{ include('common/footer.html')}}", "report/weekly_report_list.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\report\\weekly_report_list.html");
    }
}
