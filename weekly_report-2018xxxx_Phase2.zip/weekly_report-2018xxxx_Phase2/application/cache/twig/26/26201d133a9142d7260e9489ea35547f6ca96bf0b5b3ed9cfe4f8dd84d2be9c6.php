<?php

/* common/footer.html */
class __TwigTemplate_8832405c0f3963283dca797d3c9449d92bb12c5b841607db9cf860f1aa19d266 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<footer>
\t<p id=\"copyright\"><small>Copyright (c) 株式会社ミライタス All Rights Reserved.</small></p>
</footer>
</body>

</html>";
    }

    public function getTemplateName()
    {
        return "common/footer.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<footer>
\t<p id=\"copyright\"><small>Copyright (c) 株式会社ミライタス All Rights Reserved.</small></p>
</footer>
</body>

</html>", "common/footer.html", "C:\\xampp\\htdocs\\project\\report\\weekly_report-2018xxxx_Phase2\\application\\views\\common\\footer.html");
    }
}
