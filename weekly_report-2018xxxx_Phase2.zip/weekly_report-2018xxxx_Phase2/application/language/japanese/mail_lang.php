<?php

//管理者メールアドレス
$lang['admin_email'] = "";


?>