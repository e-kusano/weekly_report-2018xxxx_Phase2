<?php
//管理者
$lang['administrator'] = "管理者";

//週報
$lang['wrapper_title_all'] = "週報一覧";
$lang['wrapper_title_month'] = "[%0]の週報";
$lang['project_name'] = "参画プロジェクト名";
$lang['work_content'] = "作業内容";
$lang['reflect'] = "作業に対する疑問/不明点/反省等";
$lang['other'] = "その他";
?>